#pragma once
class Add {
	int a, b;  //�ǿ�����
public:
	void setValue(int x, int y);
	int calculate();
};

class Sub {
	int a, b;
public:
	void setValue(int x, int y);
	int calculate();
};

class Mul {
	int a, b;
public:
	void setValue(int x, int y);
	int calculate();
};

class Div{
	int a, b;
public:
	void setValue(int x, int y);
	int calculate();
};